$(document).ready(function () {
  $('select').select2({
    tags: true,
    placeholder: 'Escolha ou escreva um tipo de exercício',
    allowClear: true
  })
})
